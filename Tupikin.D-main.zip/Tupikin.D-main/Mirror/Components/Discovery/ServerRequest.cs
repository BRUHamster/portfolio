namespace Mirror.Discovery
{
    public struct ServerRequest : NetworkMessage {}
}
